export default ImagePath = {
  // MainUrl:'https://demo.webshowcase-india.com/indiadeposit/public/apis/',
  Path: 'https://devappapi.olocker.in/',
  Path1: 'https://api.myjeweller.in',
  path2: `https://olocker.co/`,
};
