import React from "react";
import { StatusBar } from "react-native";

export default (Status) => {
  return <StatusBar 
  barStyle="light-content" 
  backgroundColor={'#032e63'} />;
};
