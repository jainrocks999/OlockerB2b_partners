export default BASEURLS = {
  // MainUrl:'https://demo.webshowcase-india.com/indiadeposit/public/apis/',
  // MainUrl: 'https://api.myjeweller.in/api/Partner/',
  //MainUrl1:'https://api.myjeweller.in/api/Supplier/',
  // MainUrl2:'https://api.myjeweller.in/api/User/',
  //  MainUrl:'https://devappapi.olocker.in/api/Partner/',
  //  MainUrl1:'https://devappapi.olocker.in/api/Supplier/',
  //  MainUrl2:'https://devappapi.olocker.in/api/User/',
  // MainUrl3: `https://devappapi.olocker.in/api/Info/`
  MainUrl: 'https://olocker.co/api/',
  // MainUrl: 'https://192.168.1.29/api/'
};
// devappapi.olocker.in  api.myjeweller.in
