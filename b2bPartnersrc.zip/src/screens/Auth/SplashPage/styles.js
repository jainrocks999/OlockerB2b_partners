import {StyleSheet} from 'react-native';
export default StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#052a47',
    //backgroundColor:'#56bab5'
  },
  view: {
    alignItems: 'center',
    justifyContent: 'center',
    flex: 1,
    // paddingVertical:70,
    // marginTop:250,
  },
  image: {
    // height:90,width:'100%',
  },
});
